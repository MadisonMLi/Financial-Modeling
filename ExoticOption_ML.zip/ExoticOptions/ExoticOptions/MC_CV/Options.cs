﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MC_CV
{
    class Underlying
    {
        public string CompanyName { get; set; }
        public string Ticker { get; set; }
        public string Exchange { get; set; }
    }
    /// <summary>
    /// UnderlyingPrice class has properties of underlying price.
    /// </summary>
    class UnderlyingPrice
    {
        public Underlying Underlying { get; set; }
        public DateTime TradingDate { get; set; }
        public double Price { get; set; }
    }
    /// <summary>
    /// YieldPoint class has properties of YieldPoint.
    /// </summary>
    class YieldPoint
    {
        public double Tenor { get; set; }
        public double Rate { get; set; }
    }
    /// <summary>
    /// Options class has properties of Options. It is an abstract class for inheriting.
    /// </summary>
    abstract class Options
    {
        public UnderlyingPrice UnderlyingPrice { get; set; }
        public YieldPoint YieldPoint { get; set; }
        public double Sigma { get; set; }
        public double T { get; set; }


        // Define several virtual method for inheritance classes' override method. 
        public virtual double[,] GetPrice(double S, double r, double sigma, double T, double[,] sig, Simulator sim)
        {
            double[,] result = new double[1, 2];
            return result;
        }

        /// <summary>
        /// This is an override method to calculate delta.
        /// </summary>
        /// <param name="sig"> Normally distributed random variables. </param>
        /// <param name="sim"> Simulator class which has properties of steps and trails and some methods. </param>
        /// <returns> Get delta </returns>
        public virtual double GetDelta(double[,] sig, Simulator sim)
        {
            double r = YieldPoint.Rate;
            double diff = 0.001 * UnderlyingPrice.Price;
            double S_up = UnderlyingPrice.Price + diff;
            double S_down = UnderlyingPrice.Price - diff;
            double delta;

            delta = (GetPrice(S_up, r, Sigma, T, sig, sim)[0, 0] - GetPrice(S_down, r, Sigma, T, sig, sim)[0, 0]) / (2 * diff);


            return delta;
        }

        /// <summary>
        /// This is an override method to calculate gamma.
        /// </summary>
        /// <param name="sig"> Normally distributed random variables. </param>
        /// <param name="sim"> Simulator class which has properties of steps and trails and some methods. </param>
        /// <returns> Get gamma </returns>
        public virtual double GetGamma(double[,] sig, Simulator sim)
        {
            double S = UnderlyingPrice.Price;
            double r = YieldPoint.Rate;
            double diff = 0.001 * S;
            double S_up = S + diff;
            double S_down = S - diff;
            double gamma;

            gamma = (GetPrice(S_up, r, Sigma, T, sig, sim)[0, 0] - 2 * GetPrice(S, r, Sigma, T, sig, sim)[0, 0] + GetPrice(S_down, r, Sigma, T, sig, sim)[0, 0]) / (diff * diff);

            return gamma;
        }

        /// <summary>
        /// This is an override method to calculate vega.
        /// </summary>
        /// <param name="sig"> Normally distributed random variables. </param>
        /// <param name="sim"> Simulator class which has properties of steps and trails and some methods. </param>
        /// <returns> Get vega </returns>
        public virtual double GetVega(double[,] sig, Simulator sim)
        {
            double S = UnderlyingPrice.Price;
            double r = YieldPoint.Rate;
            double diff = 0.001 * Sigma;
            double sigma_up = Sigma + diff;
            double sigma_down = Sigma - diff;
            double vega;

            vega = (GetPrice(S, r, sigma_up, T, sig, sim)[0, 0] - GetPrice(S, r, sigma_down, T, sig, sim)[0, 0]) / (2 * diff);

            return vega;
        }

        /// <summary>
        /// This is an override method to calculate theta.
        /// </summary>
        /// <param name="sig"> Normally distributed random variables. </param>
        /// <param name="sim"> Simulator class which has properties of steps and trails and some methods. </param>
        /// <returns> Get theta </returns>
        public virtual double GetTheta(double[,] sig, Simulator sim)
        {
            double S = UnderlyingPrice.Price;
            double r = YieldPoint.Rate;
            double diff = 0.001 * T;
            double T_down = T - diff;
            double theta;

            theta = (GetPrice(S, r, Sigma, T_down, sig, sim)[0, 0] - GetPrice(S, r, Sigma, T, sig, sim)[0, 0]) / diff;

            return theta;
        }

        /// <summary>
        /// This is an override method to calculate rho.
        /// </summary>
        /// <param name="sig"> Normally distributed random variables. </param>
        /// <param name="sim"> Simulator class which has properties of steps and trails and some methods. </param>
        /// <returns> Get rho </returns>
        public virtual double GetRho(double[,] sig, Simulator sim)
        {
            double S = UnderlyingPrice.Price;
            double diff = 0.001 * YieldPoint.Rate;
            double r_up = YieldPoint.Rate + diff;
            double r_down = YieldPoint.Rate - diff;
            double rho;

            rho = (GetPrice(S, r_up, Sigma, T, sig, sim)[0, 0] - GetPrice(S, r_down, Sigma, T, sig, sim)[0, 0]) / (2 * diff);

            return rho;
        }

    }

}
