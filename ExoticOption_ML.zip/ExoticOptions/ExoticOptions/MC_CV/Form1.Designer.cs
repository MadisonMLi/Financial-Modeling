﻿namespace MC_CV
{
    partial class Monte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btmGo = new System.Windows.Forms.Button();
            this.S_text = new System.Windows.Forms.TextBox();
            this.K_text = new System.Windows.Forms.TextBox();
            this.r_text = new System.Windows.Forms.TextBox();
            this.Sigma_text = new System.Windows.Forms.TextBox();
            this.T_text = new System.Windows.Forms.TextBox();
            this.N_text = new System.Windows.Forms.TextBox();
            this.M_text = new System.Windows.Forms.TextBox();
            this.btmCall = new System.Windows.Forms.RadioButton();
            this.btmPut = new System.Windows.Forms.RadioButton();
            this.lbS = new System.Windows.Forms.Label();
            this.lbK = new System.Windows.Forms.Label();
            this.lbR = new System.Windows.Forms.Label();
            this.lbSigma = new System.Windows.Forms.Label();
            this.lbT = new System.Windows.Forms.Label();
            this.lbN = new System.Windows.Forms.Label();
            this.lbM = new System.Windows.Forms.Label();
            this.lbSE = new System.Windows.Forms.Label();
            this.lbRho = new System.Windows.Forms.Label();
            this.lbTheta = new System.Windows.Forms.Label();
            this.lbVega = new System.Windows.Forms.Label();
            this.lbGa = new System.Windows.Forms.Label();
            this.lbDelta = new System.Windows.Forms.Label();
            this.lbP = new System.Windows.Forms.Label();
            this.SE_text = new System.Windows.Forms.TextBox();
            this.Rho_text = new System.Windows.Forms.TextBox();
            this.Theta_text = new System.Windows.Forms.TextBox();
            this.Vega_text = new System.Windows.Forms.TextBox();
            this.Gamma_text = new System.Windows.Forms.TextBox();
            this.Delta_text = new System.Windows.Forms.TextBox();
            this.Price_text = new System.Windows.Forms.TextBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.Serror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Kerror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Rerror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Verror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Terror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Nerror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Merror = new System.Windows.Forms.ErrorProvider(this.components);
            this.Outputs = new System.Windows.Forms.GroupBox();
            this.Timer = new System.Windows.Forms.Label();
            this.Timer_text = new System.Windows.Forms.TextBox();
            this.Inputs = new System.Windows.Forms.GroupBox();
            this.CallPut = new System.Windows.Forms.GroupBox();
            this.Choices = new System.Windows.Forms.GroupBox();
            this.multi = new System.Windows.Forms.CheckBox();
            this.CV = new System.Windows.Forms.CheckBox();
            this.Anthetic = new System.Windows.Forms.CheckBox();
            this.cpu = new System.Windows.Forms.Label();
            this.cpuCount = new System.Windows.Forms.Label();
            this.Type = new System.Windows.Forms.GroupBox();
            this.EuroButton = new System.Windows.Forms.RadioButton();
            this.RangeButton = new System.Windows.Forms.RadioButton();
            this.LookbackButton = new System.Windows.Forms.RadioButton();
            this.BarrierButton = new System.Windows.Forms.RadioButton();
            this.AsianButton = new System.Windows.Forms.RadioButton();
            this.DigitalButton = new System.Windows.Forms.RadioButton();
            this.Barrier = new System.Windows.Forms.GroupBox();
            this.BarrierTxt = new System.Windows.Forms.TextBox();
            this.UpOutButton = new System.Windows.Forms.RadioButton();
            this.DownInButton = new System.Windows.Forms.RadioButton();
            this.DownOutButton = new System.Windows.Forms.RadioButton();
            this.UpInButton = new System.Windows.Forms.RadioButton();
            this.BarrierLabel = new System.Windows.Forms.Label();
            this.Digi = new System.Windows.Forms.GroupBox();
            this.Rebate_txt = new System.Windows.Forms.TextBox();
            this.BarrierError = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Serror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kerror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rerror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Verror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Terror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nerror)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Merror)).BeginInit();
            this.Outputs.SuspendLayout();
            this.Inputs.SuspendLayout();
            this.CallPut.SuspendLayout();
            this.Choices.SuspendLayout();
            this.Type.SuspendLayout();
            this.Barrier.SuspendLayout();
            this.Digi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BarrierError)).BeginInit();
            this.SuspendLayout();
            // 
            // btmGo
            // 
            this.btmGo.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btmGo.BackColor = System.Drawing.Color.Tan;
            this.btmGo.Font = new System.Drawing.Font("Mongolian Baiti", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmGo.Location = new System.Drawing.Point(677, 532);
            this.btmGo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btmGo.Name = "btmGo";
            this.btmGo.Size = new System.Drawing.Size(268, 99);
            this.btmGo.TabIndex = 0;
            this.btmGo.Text = "Calculate";
            this.btmGo.UseVisualStyleBackColor = false;
            this.btmGo.Click += new System.EventHandler(this.btmGo_Click);
            // 
            // S_text
            // 
            this.S_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.S_text.Location = new System.Drawing.Point(140, 53);
            this.S_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.S_text.Name = "S_text";
            this.S_text.Size = new System.Drawing.Size(149, 39);
            this.S_text.TabIndex = 1;
            this.S_text.Text = "50";
            this.S_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.S_text.TextChanged += new System.EventHandler(this.S_text_TextChanged);
            // 
            // K_text
            // 
            this.K_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.K_text.Location = new System.Drawing.Point(140, 95);
            this.K_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.K_text.Name = "K_text";
            this.K_text.Size = new System.Drawing.Size(149, 39);
            this.K_text.TabIndex = 2;
            this.K_text.Text = "50";
            this.K_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.K_text.TextChanged += new System.EventHandler(this.K_text_TextChanged);
            // 
            // r_text
            // 
            this.r_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r_text.Location = new System.Drawing.Point(140, 136);
            this.r_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.r_text.Name = "r_text";
            this.r_text.Size = new System.Drawing.Size(149, 39);
            this.r_text.TabIndex = 3;
            this.r_text.Text = "0.05";
            this.r_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.r_text.TextChanged += new System.EventHandler(this.r_text_TextChanged);
            // 
            // Sigma_text
            // 
            this.Sigma_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sigma_text.Location = new System.Drawing.Point(140, 177);
            this.Sigma_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Sigma_text.Name = "Sigma_text";
            this.Sigma_text.Size = new System.Drawing.Size(149, 39);
            this.Sigma_text.TabIndex = 4;
            this.Sigma_text.Text = "0.5";
            this.Sigma_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Sigma_text.TextChanged += new System.EventHandler(this.Sigma_text_TextChanged);
            // 
            // T_text
            // 
            this.T_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T_text.Location = new System.Drawing.Point(140, 219);
            this.T_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.T_text.Name = "T_text";
            this.T_text.Size = new System.Drawing.Size(149, 39);
            this.T_text.TabIndex = 5;
            this.T_text.Text = "1";
            this.T_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.T_text.TextChanged += new System.EventHandler(this.T_text_TextChanged);
            // 
            // N_text
            // 
            this.N_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N_text.Location = new System.Drawing.Point(140, 260);
            this.N_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.N_text.Name = "N_text";
            this.N_text.Size = new System.Drawing.Size(149, 39);
            this.N_text.TabIndex = 6;
            this.N_text.Text = "100";
            this.N_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.N_text.TextChanged += new System.EventHandler(this.N_text_TextChanged);
            // 
            // M_text
            // 
            this.M_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M_text.Location = new System.Drawing.Point(140, 301);
            this.M_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.M_text.Name = "M_text";
            this.M_text.Size = new System.Drawing.Size(149, 39);
            this.M_text.TabIndex = 7;
            this.M_text.Text = "10000";
            this.M_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.M_text.TextChanged += new System.EventHandler(this.M_text_TextChanged);
            // 
            // btmCall
            // 
            this.btmCall.AutoSize = true;
            this.btmCall.Checked = true;
            this.btmCall.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmCall.Location = new System.Drawing.Point(38, 49);
            this.btmCall.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btmCall.Name = "btmCall";
            this.btmCall.Size = new System.Drawing.Size(76, 31);
            this.btmCall.TabIndex = 8;
            this.btmCall.TabStop = true;
            this.btmCall.Text = "Call";
            this.btmCall.UseVisualStyleBackColor = true;
            // 
            // btmPut
            // 
            this.btmPut.AutoSize = true;
            this.btmPut.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmPut.Location = new System.Drawing.Point(38, 92);
            this.btmPut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btmPut.Name = "btmPut";
            this.btmPut.Size = new System.Drawing.Size(79, 31);
            this.btmPut.TabIndex = 9;
            this.btmPut.Text = "Puts";
            this.btmPut.UseVisualStyleBackColor = true;
            // 
            // lbS
            // 
            this.lbS.AutoSize = true;
            this.lbS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbS.Location = new System.Drawing.Point(18, 57);
            this.lbS.Name = "lbS";
            this.lbS.Size = new System.Drawing.Size(118, 27);
            this.lbS.TabIndex = 10;
            this.lbS.Text = "Underlying";
            this.lbS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbK
            // 
            this.lbK.AutoSize = true;
            this.lbK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbK.Location = new System.Drawing.Point(62, 99);
            this.lbK.Name = "lbK";
            this.lbK.Size = new System.Drawing.Size(68, 27);
            this.lbK.TabIndex = 11;
            this.lbK.Text = "Strike";
            this.lbK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbR
            // 
            this.lbR.AutoSize = true;
            this.lbR.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbR.Location = new System.Drawing.Point(2, 140);
            this.lbR.Name = "lbR";
            this.lbR.Size = new System.Drawing.Size(136, 27);
            this.lbR.TabIndex = 12;
            this.lbR.Text = "Interest Rate";
            this.lbR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSigma
            // 
            this.lbSigma.AutoSize = true;
            this.lbSigma.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSigma.Location = new System.Drawing.Point(34, 181);
            this.lbSigma.Name = "lbSigma";
            this.lbSigma.Size = new System.Drawing.Size(98, 27);
            this.lbSigma.TabIndex = 13;
            this.lbSigma.Text = "Volatility";
            this.lbSigma.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbT
            // 
            this.lbT.AutoSize = true;
            this.lbT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbT.Location = new System.Drawing.Point(61, 223);
            this.lbT.Name = "lbT";
            this.lbT.Size = new System.Drawing.Size(67, 27);
            this.lbT.TabIndex = 14;
            this.lbT.Text = "Tenor";
            this.lbT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbN
            // 
            this.lbN.AutoSize = true;
            this.lbN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbN.Location = new System.Drawing.Point(64, 264);
            this.lbN.Name = "lbN";
            this.lbN.Size = new System.Drawing.Size(63, 27);
            this.lbN.TabIndex = 15;
            this.lbN.Text = "Steps";
            this.lbN.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbM
            // 
            this.lbM.AutoSize = true;
            this.lbM.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbM.Location = new System.Drawing.Point(60, 305);
            this.lbM.Name = "lbM";
            this.lbM.Size = new System.Drawing.Size(65, 27);
            this.lbM.TabIndex = 16;
            this.lbM.Text = "Trails";
            this.lbM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSE
            // 
            this.lbSE.AutoSize = true;
            this.lbSE.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSE.Location = new System.Drawing.Point(2, 299);
            this.lbSE.Name = "lbSE";
            this.lbSE.Size = new System.Drawing.Size(94, 27);
            this.lbSE.TabIndex = 33;
            this.lbSE.Text = "StdError";
            this.lbSE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbSE.Click += new System.EventHandler(this.lbSE_Click);
            // 
            // lbRho
            // 
            this.lbRho.AutoSize = true;
            this.lbRho.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRho.Location = new System.Drawing.Point(40, 261);
            this.lbRho.Name = "lbRho";
            this.lbRho.Size = new System.Drawing.Size(52, 27);
            this.lbRho.TabIndex = 32;
            this.lbRho.Text = "Rho";
            this.lbRho.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTheta
            // 
            this.lbTheta.AutoSize = true;
            this.lbTheta.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTheta.Location = new System.Drawing.Point(30, 216);
            this.lbTheta.Name = "lbTheta";
            this.lbTheta.Size = new System.Drawing.Size(67, 27);
            this.lbTheta.TabIndex = 31;
            this.lbTheta.Text = "Theta";
            this.lbTheta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbVega
            // 
            this.lbVega.AutoSize = true;
            this.lbVega.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVega.Location = new System.Drawing.Point(37, 175);
            this.lbVega.Name = "lbVega";
            this.lbVega.Size = new System.Drawing.Size(58, 27);
            this.lbVega.TabIndex = 30;
            this.lbVega.Text = "Vega";
            this.lbVega.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbGa
            // 
            this.lbGa.AutoSize = true;
            this.lbGa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGa.Location = new System.Drawing.Point(15, 133);
            this.lbGa.Name = "lbGa";
            this.lbGa.Size = new System.Drawing.Size(87, 27);
            this.lbGa.TabIndex = 29;
            this.lbGa.Text = "Gamma";
            this.lbGa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDelta
            // 
            this.lbDelta.AutoSize = true;
            this.lbDelta.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDelta.Location = new System.Drawing.Point(34, 92);
            this.lbDelta.Name = "lbDelta";
            this.lbDelta.Size = new System.Drawing.Size(64, 27);
            this.lbDelta.TabIndex = 28;
            this.lbDelta.Text = "Delta";
            this.lbDelta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbP
            // 
            this.lbP.AutoSize = true;
            this.lbP.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbP.Location = new System.Drawing.Point(33, 51);
            this.lbP.Name = "lbP";
            this.lbP.Size = new System.Drawing.Size(62, 27);
            this.lbP.TabIndex = 27;
            this.lbP.Text = "Price";
            this.lbP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SE_text
            // 
            this.SE_text.Enabled = false;
            this.SE_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SE_text.Location = new System.Drawing.Point(98, 299);
            this.SE_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SE_text.Name = "SE_text";
            this.SE_text.Size = new System.Drawing.Size(219, 39);
            this.SE_text.TabIndex = 24;
            // 
            // Rho_text
            // 
            this.Rho_text.Enabled = false;
            this.Rho_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rho_text.Location = new System.Drawing.Point(98, 257);
            this.Rho_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Rho_text.Name = "Rho_text";
            this.Rho_text.Size = new System.Drawing.Size(219, 39);
            this.Rho_text.TabIndex = 23;
            // 
            // Theta_text
            // 
            this.Theta_text.Enabled = false;
            this.Theta_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Theta_text.Location = new System.Drawing.Point(98, 216);
            this.Theta_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Theta_text.Name = "Theta_text";
            this.Theta_text.Size = new System.Drawing.Size(219, 39);
            this.Theta_text.TabIndex = 22;
            // 
            // Vega_text
            // 
            this.Vega_text.Enabled = false;
            this.Vega_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vega_text.Location = new System.Drawing.Point(98, 175);
            this.Vega_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Vega_text.Name = "Vega_text";
            this.Vega_text.Size = new System.Drawing.Size(219, 39);
            this.Vega_text.TabIndex = 21;
            // 
            // Gamma_text
            // 
            this.Gamma_text.Enabled = false;
            this.Gamma_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gamma_text.Location = new System.Drawing.Point(98, 133);
            this.Gamma_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Gamma_text.Name = "Gamma_text";
            this.Gamma_text.Size = new System.Drawing.Size(219, 39);
            this.Gamma_text.TabIndex = 20;
            // 
            // Delta_text
            // 
            this.Delta_text.Enabled = false;
            this.Delta_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delta_text.Location = new System.Drawing.Point(98, 92);
            this.Delta_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Delta_text.Name = "Delta_text";
            this.Delta_text.Size = new System.Drawing.Size(219, 39);
            this.Delta_text.TabIndex = 19;
            // 
            // Price_text
            // 
            this.Price_text.Enabled = false;
            this.Price_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_text.Location = new System.Drawing.Point(98, 51);
            this.Price_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Price_text.Name = "Price_text";
            this.Price_text.Size = new System.Drawing.Size(219, 39);
            this.Price_text.TabIndex = 18;
            // 
            // progressBar
            // 
            this.progressBar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.progressBar.Location = new System.Drawing.Point(6, 358);
            this.progressBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(315, 48);
            this.progressBar.TabIndex = 35;
            this.progressBar.Click += new System.EventHandler(this.progressBar_Click);
            // 
            // Serror
            // 
            this.Serror.ContainerControl = this;
            // 
            // Kerror
            // 
            this.Kerror.ContainerControl = this;
            // 
            // Rerror
            // 
            this.Rerror.ContainerControl = this;
            // 
            // Verror
            // 
            this.Verror.ContainerControl = this;
            // 
            // Terror
            // 
            this.Terror.ContainerControl = this;
            // 
            // Nerror
            // 
            this.Nerror.ContainerControl = this;
            // 
            // Merror
            // 
            this.Merror.ContainerControl = this;
            // 
            // Outputs
            // 
            this.Outputs.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Outputs.Controls.Add(this.Timer);
            this.Outputs.Controls.Add(this.Timer_text);
            this.Outputs.Controls.Add(this.lbSE);
            this.Outputs.Controls.Add(this.Price_text);
            this.Outputs.Controls.Add(this.Delta_text);
            this.Outputs.Controls.Add(this.lbRho);
            this.Outputs.Controls.Add(this.Gamma_text);
            this.Outputs.Controls.Add(this.lbTheta);
            this.Outputs.Controls.Add(this.Vega_text);
            this.Outputs.Controls.Add(this.lbVega);
            this.Outputs.Controls.Add(this.Theta_text);
            this.Outputs.Controls.Add(this.lbGa);
            this.Outputs.Controls.Add(this.Rho_text);
            this.Outputs.Controls.Add(this.lbDelta);
            this.Outputs.Controls.Add(this.SE_text);
            this.Outputs.Controls.Add(this.lbP);
            this.Outputs.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Outputs.Location = new System.Drawing.Point(349, 11);
            this.Outputs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Outputs.Name = "Outputs";
            this.Outputs.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Outputs.Size = new System.Drawing.Size(351, 449);
            this.Outputs.TabIndex = 36;
            this.Outputs.TabStop = false;
            this.Outputs.Text = "Outputs";
            // 
            // Timer
            // 
            this.Timer.AutoSize = true;
            this.Timer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Timer.Location = new System.Drawing.Point(25, 347);
            this.Timer.Name = "Timer";
            this.Timer.Size = new System.Drawing.Size(68, 27);
            this.Timer.TabIndex = 35;
            this.Timer.Text = "Timer";
            this.Timer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Timer_text
            // 
            this.Timer_text.Enabled = false;
            this.Timer_text.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Timer_text.Location = new System.Drawing.Point(98, 343);
            this.Timer_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Timer_text.Name = "Timer_text";
            this.Timer_text.Size = new System.Drawing.Size(219, 39);
            this.Timer_text.TabIndex = 34;
            // 
            // Inputs
            // 
            this.Inputs.AutoSize = true;
            this.Inputs.Controls.Add(this.Sigma_text);
            this.Inputs.Controls.Add(this.S_text);
            this.Inputs.Controls.Add(this.K_text);
            this.Inputs.Controls.Add(this.lbM);
            this.Inputs.Controls.Add(this.r_text);
            this.Inputs.Controls.Add(this.lbN);
            this.Inputs.Controls.Add(this.progressBar);
            this.Inputs.Controls.Add(this.T_text);
            this.Inputs.Controls.Add(this.lbT);
            this.Inputs.Controls.Add(this.N_text);
            this.Inputs.Controls.Add(this.lbSigma);
            this.Inputs.Controls.Add(this.M_text);
            this.Inputs.Controls.Add(this.lbR);
            this.Inputs.Controls.Add(this.lbS);
            this.Inputs.Controls.Add(this.lbK);
            this.Inputs.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inputs.Location = new System.Drawing.Point(14, 11);
            this.Inputs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Inputs.Name = "Inputs";
            this.Inputs.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Inputs.Size = new System.Drawing.Size(328, 449);
            this.Inputs.TabIndex = 37;
            this.Inputs.TabStop = false;
            this.Inputs.Text = "Inputs";
            this.Inputs.Enter += new System.EventHandler(this.Inputs_Enter);
            // 
            // CallPut
            // 
            this.CallPut.AutoSize = true;
            this.CallPut.Controls.Add(this.btmCall);
            this.CallPut.Controls.Add(this.btmPut);
            this.CallPut.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CallPut.Location = new System.Drawing.Point(14, 473);
            this.CallPut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CallPut.Name = "CallPut";
            this.CallPut.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CallPut.Size = new System.Drawing.Size(162, 168);
            this.CallPut.TabIndex = 38;
            this.CallPut.TabStop = false;
            this.CallPut.Text = "Call / Put";
            // 
            // Choices
            // 
            this.Choices.AutoSize = true;
            this.Choices.Controls.Add(this.multi);
            this.Choices.Controls.Add(this.CV);
            this.Choices.Controls.Add(this.Anthetic);
            this.Choices.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Choices.Location = new System.Drawing.Point(182, 465);
            this.Choices.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Choices.Name = "Choices";
            this.Choices.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Choices.Size = new System.Drawing.Size(164, 175);
            this.Choices.TabIndex = 39;
            this.Choices.TabStop = false;
            this.Choices.Text = "Choices";
            // 
            // multi
            // 
            this.multi.AutoSize = true;
            this.multi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multi.Location = new System.Drawing.Point(7, 101);
            this.multi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multi.Name = "multi";
            this.multi.Size = new System.Drawing.Size(151, 31);
            this.multi.TabIndex = 2;
            this.multi.Text = "Multithread";
            this.multi.UseVisualStyleBackColor = true;
            // 
            // CV
            // 
            this.CV.AutoSize = true;
            this.CV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CV.Location = new System.Drawing.Point(7, 65);
            this.CV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CV.Name = "CV";
            this.CV.Size = new System.Drawing.Size(134, 31);
            this.CV.TabIndex = 1;
            this.CV.Text = "CV_Delta";
            this.CV.UseVisualStyleBackColor = true;
            // 
            // Anthetic
            // 
            this.Anthetic.AutoSize = true;
            this.Anthetic.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Anthetic.Location = new System.Drawing.Point(7, 32);
            this.Anthetic.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Anthetic.Name = "Anthetic";
            this.Anthetic.Size = new System.Drawing.Size(121, 31);
            this.Anthetic.TabIndex = 0;
            this.Anthetic.Text = "Anthetic";
            this.Anthetic.UseVisualStyleBackColor = true;
            // 
            // cpu
            // 
            this.cpu.AutoSize = true;
            this.cpu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpu.Location = new System.Drawing.Point(752, 23);
            this.cpu.Name = "cpu";
            this.cpu.Size = new System.Drawing.Size(64, 27);
            this.cpu.TabIndex = 40;
            this.cpu.Text = "CPU:";
            // 
            // cpuCount
            // 
            this.cpuCount.AutoSize = true;
            this.cpuCount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpuCount.Location = new System.Drawing.Point(818, 23);
            this.cpuCount.Name = "cpuCount";
            this.cpuCount.Size = new System.Drawing.Size(24, 27);
            this.cpuCount.TabIndex = 41;
            this.cpuCount.Text = "4";
            // 
            // Type
            // 
            this.Type.Controls.Add(this.EuroButton);
            this.Type.Controls.Add(this.RangeButton);
            this.Type.Controls.Add(this.LookbackButton);
            this.Type.Controls.Add(this.BarrierButton);
            this.Type.Controls.Add(this.AsianButton);
            this.Type.Controls.Add(this.DigitalButton);
            this.Type.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Type.Location = new System.Drawing.Point(356, 469);
            this.Type.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Type.Name = "Type";
            this.Type.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Type.Size = new System.Drawing.Size(310, 172);
            this.Type.TabIndex = 42;
            this.Type.TabStop = false;
            this.Type.Text = "Type";
            // 
            // EuroButton
            // 
            this.EuroButton.AutoSize = true;
            this.EuroButton.Checked = true;
            this.EuroButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EuroButton.Location = new System.Drawing.Point(36, 33);
            this.EuroButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EuroButton.Name = "EuroButton";
            this.EuroButton.Size = new System.Drawing.Size(130, 31);
            this.EuroButton.TabIndex = 10;
            this.EuroButton.TabStop = true;
            this.EuroButton.Text = "European";
            this.EuroButton.UseVisualStyleBackColor = true;
            // 
            // RangeButton
            // 
            this.RangeButton.AutoSize = true;
            this.RangeButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RangeButton.Location = new System.Drawing.Point(168, 119);
            this.RangeButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RangeButton.Name = "RangeButton";
            this.RangeButton.Size = new System.Drawing.Size(98, 31);
            this.RangeButton.TabIndex = 9;
            this.RangeButton.TabStop = true;
            this.RangeButton.Text = "Range";
            this.RangeButton.UseVisualStyleBackColor = true;
            // 
            // LookbackButton
            // 
            this.LookbackButton.AutoSize = true;
            this.LookbackButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LookbackButton.Location = new System.Drawing.Point(168, 76);
            this.LookbackButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LookbackButton.Name = "LookbackButton";
            this.LookbackButton.Size = new System.Drawing.Size(134, 31);
            this.LookbackButton.TabIndex = 9;
            this.LookbackButton.TabStop = true;
            this.LookbackButton.Text = "Lookback";
            this.LookbackButton.UseVisualStyleBackColor = true;
            // 
            // BarrierButton
            // 
            this.BarrierButton.AutoSize = true;
            this.BarrierButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarrierButton.Location = new System.Drawing.Point(168, 33);
            this.BarrierButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BarrierButton.Name = "BarrierButton";
            this.BarrierButton.Size = new System.Drawing.Size(105, 31);
            this.BarrierButton.TabIndex = 9;
            this.BarrierButton.TabStop = true;
            this.BarrierButton.Text = "Barrier";
            this.BarrierButton.UseVisualStyleBackColor = true;
            // 
            // AsianButton
            // 
            this.AsianButton.AutoSize = true;
            this.AsianButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AsianButton.Location = new System.Drawing.Point(35, 75);
            this.AsianButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AsianButton.Name = "AsianButton";
            this.AsianButton.Size = new System.Drawing.Size(92, 31);
            this.AsianButton.TabIndex = 9;
            this.AsianButton.TabStop = true;
            this.AsianButton.Text = "Asian";
            this.AsianButton.UseVisualStyleBackColor = true;
            // 
            // DigitalButton
            // 
            this.DigitalButton.AutoSize = true;
            this.DigitalButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigitalButton.Location = new System.Drawing.Point(35, 119);
            this.DigitalButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DigitalButton.Name = "DigitalButton";
            this.DigitalButton.Size = new System.Drawing.Size(101, 31);
            this.DigitalButton.TabIndex = 9;
            this.DigitalButton.TabStop = true;
            this.DigitalButton.Text = "Digital";
            this.DigitalButton.UseVisualStyleBackColor = true;
            // 
            // Barrier
            // 
            this.Barrier.Controls.Add(this.BarrierTxt);
            this.Barrier.Controls.Add(this.UpOutButton);
            this.Barrier.Controls.Add(this.DownInButton);
            this.Barrier.Controls.Add(this.DownOutButton);
            this.Barrier.Controls.Add(this.UpInButton);
            this.Barrier.Controls.Add(this.BarrierLabel);
            this.Barrier.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Barrier.Location = new System.Drawing.Point(706, 65);
            this.Barrier.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Barrier.Name = "Barrier";
            this.Barrier.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Barrier.Size = new System.Drawing.Size(213, 337);
            this.Barrier.TabIndex = 42;
            this.Barrier.TabStop = false;
            this.Barrier.Text = "Barrier Properties";
            // 
            // BarrierTxt
            // 
            this.BarrierTxt.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarrierTxt.Location = new System.Drawing.Point(11, 276);
            this.BarrierTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BarrierTxt.Name = "BarrierTxt";
            this.BarrierTxt.Size = new System.Drawing.Size(148, 39);
            this.BarrierTxt.TabIndex = 28;
            this.BarrierTxt.Text = "60";
            this.BarrierTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BarrierTxt.TextChanged += new System.EventHandler(this.BarrierTxt_TextChanged);
            // 
            // UpOutButton
            // 
            this.UpOutButton.AutoSize = true;
            this.UpOutButton.Checked = true;
            this.UpOutButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpOutButton.Location = new System.Drawing.Point(11, 68);
            this.UpOutButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.UpOutButton.Name = "UpOutButton";
            this.UpOutButton.Size = new System.Drawing.Size(148, 31);
            this.UpOutButton.TabIndex = 8;
            this.UpOutButton.TabStop = true;
            this.UpOutButton.Text = "Up and Out";
            this.UpOutButton.UseVisualStyleBackColor = true;
            // 
            // DownInButton
            // 
            this.DownInButton.AutoSize = true;
            this.DownInButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DownInButton.Location = new System.Drawing.Point(11, 167);
            this.DownInButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DownInButton.Name = "DownInButton";
            this.DownInButton.Size = new System.Drawing.Size(162, 31);
            this.DownInButton.TabIndex = 9;
            this.DownInButton.TabStop = true;
            this.DownInButton.Text = "Down and In";
            this.DownInButton.UseVisualStyleBackColor = true;
            // 
            // DownOutButton
            // 
            this.DownOutButton.AutoSize = true;
            this.DownOutButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DownOutButton.Location = new System.Drawing.Point(11, 132);
            this.DownOutButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DownOutButton.Name = "DownOutButton";
            this.DownOutButton.Size = new System.Drawing.Size(178, 31);
            this.DownOutButton.TabIndex = 9;
            this.DownOutButton.TabStop = true;
            this.DownOutButton.Text = "Down and Out";
            this.DownOutButton.UseVisualStyleBackColor = true;
            // 
            // UpInButton
            // 
            this.UpInButton.AutoSize = true;
            this.UpInButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpInButton.Location = new System.Drawing.Point(11, 101);
            this.UpInButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.UpInButton.Name = "UpInButton";
            this.UpInButton.Size = new System.Drawing.Size(132, 31);
            this.UpInButton.TabIndex = 9;
            this.UpInButton.TabStop = true;
            this.UpInButton.Text = "Up and In";
            this.UpInButton.UseVisualStyleBackColor = true;
            // 
            // BarrierLabel
            // 
            this.BarrierLabel.AutoSize = true;
            this.BarrierLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarrierLabel.Location = new System.Drawing.Point(7, 231);
            this.BarrierLabel.Name = "BarrierLabel";
            this.BarrierLabel.Size = new System.Drawing.Size(80, 27);
            this.BarrierLabel.TabIndex = 27;
            this.BarrierLabel.Text = "Barrier";
            this.BarrierLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Digi
            // 
            this.Digi.Controls.Add(this.Rebate_txt);
            this.Digi.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Digi.Location = new System.Drawing.Point(706, 411);
            this.Digi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Digi.Name = "Digi";
            this.Digi.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Digi.Size = new System.Drawing.Size(213, 96);
            this.Digi.TabIndex = 43;
            this.Digi.TabStop = false;
            this.Digi.Text = "Digital Rebate";
            // 
            // Rebate_txt
            // 
            this.Rebate_txt.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rebate_txt.Location = new System.Drawing.Point(10, 36);
            this.Rebate_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Rebate_txt.Name = "Rebate_txt";
            this.Rebate_txt.Size = new System.Drawing.Size(149, 39);
            this.Rebate_txt.TabIndex = 40;
            this.Rebate_txt.Text = "5";
            this.Rebate_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Rebate_txt.TextChanged += new System.EventHandler(this.S_text_TextChanged);
            // 
            // BarrierError
            // 
            this.BarrierError.ContainerControl = this;
            // 
            // Monte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(963, 657);
            this.Controls.Add(this.Digi);
            this.Controls.Add(this.Barrier);
            this.Controls.Add(this.Type);
            this.Controls.Add(this.cpuCount);
            this.Controls.Add(this.cpu);
            this.Controls.Add(this.CallPut);
            this.Controls.Add(this.Inputs);
            this.Controls.Add(this.Choices);
            this.Controls.Add(this.Outputs);
            this.Controls.Add(this.btmGo);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Monte";
            this.Text = "Monte Carlo Calculator";
            this.Load += new System.EventHandler(this.Monte_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Serror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kerror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rerror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Verror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Terror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nerror)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Merror)).EndInit();
            this.Outputs.ResumeLayout(false);
            this.Outputs.PerformLayout();
            this.Inputs.ResumeLayout(false);
            this.Inputs.PerformLayout();
            this.CallPut.ResumeLayout(false);
            this.CallPut.PerformLayout();
            this.Choices.ResumeLayout(false);
            this.Choices.PerformLayout();
            this.Type.ResumeLayout(false);
            this.Type.PerformLayout();
            this.Barrier.ResumeLayout(false);
            this.Barrier.PerformLayout();
            this.Digi.ResumeLayout(false);
            this.Digi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BarrierError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btmGo;
        private System.Windows.Forms.TextBox S_text;
        private System.Windows.Forms.TextBox K_text;
        private System.Windows.Forms.TextBox r_text;
        private System.Windows.Forms.TextBox Sigma_text;
        private System.Windows.Forms.TextBox T_text;
        private System.Windows.Forms.TextBox N_text;
        private System.Windows.Forms.TextBox M_text;
        private System.Windows.Forms.RadioButton btmCall;
        private System.Windows.Forms.RadioButton btmPut;
        private System.Windows.Forms.Label lbS;
        private System.Windows.Forms.Label lbK;
        private System.Windows.Forms.Label lbR;
        private System.Windows.Forms.Label lbSigma;
        private System.Windows.Forms.Label lbT;
        private System.Windows.Forms.Label lbN;
        private System.Windows.Forms.Label lbM;
        private System.Windows.Forms.Label lbSE;
        private System.Windows.Forms.Label lbRho;
        private System.Windows.Forms.Label lbTheta;
        private System.Windows.Forms.Label lbVega;
        private System.Windows.Forms.Label lbGa;
        private System.Windows.Forms.Label lbDelta;
        private System.Windows.Forms.Label lbP;
        private System.Windows.Forms.TextBox SE_text;
        private System.Windows.Forms.TextBox Rho_text;
        private System.Windows.Forms.TextBox Theta_text;
        private System.Windows.Forms.TextBox Vega_text;
        private System.Windows.Forms.TextBox Gamma_text;
        private System.Windows.Forms.TextBox Delta_text;
        private System.Windows.Forms.TextBox Price_text;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.ErrorProvider Serror;
        private System.Windows.Forms.ErrorProvider Kerror;
        private System.Windows.Forms.ErrorProvider Rerror;
        private System.Windows.Forms.ErrorProvider Verror;
        private System.Windows.Forms.ErrorProvider Terror;
        private System.Windows.Forms.ErrorProvider Nerror;
        private System.Windows.Forms.ErrorProvider Merror;
        private System.Windows.Forms.GroupBox Inputs;
        private System.Windows.Forms.GroupBox Outputs;
        private System.Windows.Forms.GroupBox Choices;
        private System.Windows.Forms.CheckBox Anthetic;
        private System.Windows.Forms.GroupBox CallPut;
        private System.Windows.Forms.CheckBox CV;
        private System.Windows.Forms.Label Timer;
        private System.Windows.Forms.TextBox Timer_text;
        private System.Windows.Forms.Label cpuCount;
        private System.Windows.Forms.Label cpu;
        private System.Windows.Forms.CheckBox multi;
        private System.Windows.Forms.GroupBox Barrier;
        private System.Windows.Forms.RadioButton UpOutButton;
        private System.Windows.Forms.RadioButton DownInButton;
        private System.Windows.Forms.RadioButton DownOutButton;
        private System.Windows.Forms.RadioButton UpInButton;
        private System.Windows.Forms.Label BarrierLabel;
        private System.Windows.Forms.GroupBox Type;
        private System.Windows.Forms.RadioButton EuroButton;
        private System.Windows.Forms.RadioButton RangeButton;
        private System.Windows.Forms.RadioButton LookbackButton;
        private System.Windows.Forms.RadioButton BarrierButton;
        private System.Windows.Forms.RadioButton AsianButton;
        private System.Windows.Forms.RadioButton DigitalButton;
        private System.Windows.Forms.GroupBox Digi;
        private System.Windows.Forms.TextBox Rebate_txt;
        private System.Windows.Forms.ErrorProvider BarrierError;
        private System.Windows.Forms.TextBox BarrierTxt;
    }
}

