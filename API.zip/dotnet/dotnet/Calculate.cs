// namespace HC;
// public class WeatherForecast
// {
//     public DateTime Date { get; set; }

//     public int TemperatureC { get; set; }

//     public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

//     public string? Summary { get; set; }
// }
// public class OptionInputs
//     {
//         public string CompanyName { get; set; }
//         public string Ticker { get; set; }
//         public string Exchange { get; set; }
//         public string type { get; set; }
//         public double Tenor { get; set; }
//         public double Rate { get; set; }
//         public double Strike { get; set; }
//         public double S { get; set; }
//         public double T { get; set; }
//         public double r { get; set; }
//         public double sigma { get; set; }
//         public long Simulator { get; set; }

//         public double sig { get; set; }
//         public long steps { get; set; }
//         public double trails { get; set; }
//         public bool Anti { get; set; }
//         public bool CV { get; set; }

//         public bool Multi { get; set; }
//         public double rebate { get; set; }
//     }


//     public class OutputResults
//     {
//         public double result { get; set;}
//         public double SE { get; set;}
//         public double delta { get; set;}
//         public double gamma { get; set;}
//         public double vega { get; set;}
//         public double theta { get; set;}
//         public double rho { get; set;}
//     }
