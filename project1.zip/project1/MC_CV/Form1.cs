﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace MC_CV
{
    public partial class Monte : Form
    {
        Stopwatch watch = new Stopwatch();

        public Monte()
        {
            InitializeComponent();
        }

        private void lbSE_Click(object sender, EventArgs e)
        {

        }

        private void btmGo_Click(object sender, EventArgs e)
        {
            try
            {
                // Initialize progressBar
                progressBar.Visible = true;
                progressBar.Value = 0;
                progressBar.Maximum = 100;
                progressBar.BackColor = Color.Green;
                // Start watch
                watch.Reset();
                watch.Start();               
                // Instantiate non-static class
                UnderlyingPrice udl = new UnderlyingPrice()
                {
                    Price = Convert.ToDouble(S_text.Text)
                };
                YieldPoint yp = new YieldPoint()
                {
                    Rate = Convert.ToDouble(r_text.Text)
                };
                European eur = new European()
                {
                    UnderlyingPrice = udl,
                    YieldPoint = yp,
                    Strike = Convert.ToDouble(K_text.Text),
                    T = Convert.ToDouble(T_text.Text),
                    Sigma = Convert.ToDouble(Sigma_text.Text)
                };

                Simulator sim = new Simulator()
                {
                    M = Convert.ToInt32(M_text.Text),
                    N = Convert.ToInt32(N_text.Text)
                };

                //Control_Variable cv_ins = new Control_Variable();

                // Judge if user wants to calculate call options or put options.
                if (btmCall.Checked == true)
                {
                    eur.Iscall = true;
                }
                else if (btmPut.Checked == true)
                {
                    eur.Iscall = false;
                }

                // Judge if user wants to use antithetic or not.
                if (Anthetic.Checked == true)
                {
                    sim.Anti = true;
                }
                else
                {
                    sim.Anti = false;
                }

                // Judge if user wants to use delta control variable or not.
                if (CV.Checked == true)
                {
                    sim.CV = true;
                }
                else
                {
                    sim.CV = false;
                }



                // Generate normally distributed random variables.
                double[,] sig = sim.Norm_polar();
                // Calculate European option price.
                // Add value to progressBar to make progressBar progress.
                double v = eur.GetPrice(eur.UnderlyingPrice.Price, eur.YieldPoint.Rate, eur.Sigma, eur.T, sig, sim)[0, 0];
                progressBar.Value += 40;
                // Calculate standard error
                double SE = eur.GetPrice(eur.UnderlyingPrice.Price, eur.YieldPoint.Rate, eur.Sigma, eur.T, sig, sim)[0, 1];
                progressBar.Value += 20;
                // Calculate delta
                double delta = eur.GetDelta(sig, sim);
                progressBar.Value += 8;
                // Calculate gamma
                double gamma = eur.GetGamma(sig, sim);
                progressBar.Value += 8;
                // Calculate vega
                double vega = eur.GetVega(sig, sim);
                progressBar.Value += 8;
                // Calculate rho
                double rho = eur.GetRho(sig, sim);
                progressBar.Value += 8;
                // Calculate theta
                double theta = eur.GetTheta(sig, sim);
                progressBar.Value += 8;

                // Assign all the outputs above to responding textboxes.

                Price_text.Text = v.ToString();                
                SE_text.Text = SE.ToString();                
                Delta_text.Text = delta.ToString();                
                Gamma_text.Text = gamma.ToString();                
                Vega_text.Text = vega.ToString();               
                Rho_text.Text = rho.ToString();               
                Theta_text.Text = theta.ToString();               

                watch.Stop();
                Timer_text.Text = watch.Elapsed.Hours.ToString() + "h" + " : " + watch.Elapsed.Minutes.ToString() +
                     "m" + " : " + watch.Elapsed.Seconds.ToString() + "s" + " : " + watch.Elapsed.Milliseconds.ToString() +
                     "ms";

            }
            catch (FormatException)
            {
                MessageBox.Show("ERROR! You entered wrong data. Or you haven't filled in all blanks!" + "\n" +
                    "Please try again!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void Monte_Load(object sender, EventArgs e)
        {

        }
        // All the following code is to tell users they enter wrong values when they fill blanks.
        private void S_text_TextChanged(object sender, EventArgs e)
        {
            double g;
            // Find if entered value is right
            if (!double.TryParse(S_text.Text, out g))
            {
                // If not, make the blank to be pink
                S_text.BackColor = Color.Pink;
                // and have a error point
                Serror.SetError(S_text, "Please enter a number!");
            }
            else
            {
                S_text.BackColor = Color.White;
                Serror.SetError(S_text, string.Empty);
            }
        }

        private void K_text_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(K_text.Text, out double g))
            {
                K_text.BackColor = Color.Pink;
                Kerror.SetError(K_text, "Please enter a number!");
            }
            else
            {
                K_text.BackColor = Color.White;
                Kerror.SetError(K_text, string.Empty);
            }
        }

        private void r_text_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(r_text.Text, out double g))
            {
                r_text.BackColor = Color.Pink;
                Rerror.SetError(r_text, "Please enter a number!");
            }
            else
            {
                r_text.BackColor = Color.White;
                Rerror.SetError(r_text, string.Empty);
            }
        }

        private void Sigma_text_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(Sigma_text.Text, out double g))
            {
                Sigma_text.BackColor = Color.Pink;
                Verror.SetError(Sigma_text, "Please enter a number!");
            }
            else
            {
                Sigma_text.BackColor = Color.White;
                Verror.SetError(Sigma_text, string.Empty);
            }
        }

        private void T_text_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(T_text.Text, out double g))
            {
                T_text.BackColor = Color.Pink;
                Terror.SetError(T_text, "Please enter a number!");
            }
            else
            {
                T_text.BackColor = Color.White;
                Terror.SetError(T_text, string.Empty);
            }
        }

        private void N_text_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(N_text.Text, out int g))
            {
                N_text.BackColor = Color.Pink;
                Nerror.SetError(N_text, "Please enter an int!");
            }
            else
            {
                N_text.BackColor = Color.White;
                Nerror.SetError(N_text, string.Empty);
            }
        }

        private void M_text_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(M_text.Text, out int g))
            {
                M_text.BackColor = Color.Pink;
                Merror.SetError(M_text, "Please enter an int!");
            }
            else
            {
                M_text.BackColor = Color.White;
                Merror.SetError(M_text, string.Empty);
            }
        }

        private void Inputs_Enter(object sender, EventArgs e)
        {

        }

        private void lbS_Click(object sender, EventArgs e)
        {

        }
    }
}
