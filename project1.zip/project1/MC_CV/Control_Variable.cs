﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.Distributions;

namespace MC_CV
{
    public static class BS
    {
        /// <summary>
        /// This is a method to calculate delta using black-scholes fomula.
        /// </summary>
        /// <param name="Iscall">Judge whether call or put options</param>
        /// <param name="S">Underlying prices</param>
        /// <param name="K">Strike prices</param>
        /// <param name="r">Interest rate</param>
        /// <param name="sigma">Volatility of underlying price</param>
        /// <param name="T">Options tenor</param>
        /// <param name="t">Passed time period</param>
        /// <returns></returns>
        public static double BS_Delta(bool Iscall, double S, double K, double r, double sigma, double T, double t)
        {
            double d1;
            double delta;
            // Calculate d1
            d1 = (Math.Log(S / K) + (r + (sigma * sigma) / 2) * (T-t)) / (sigma * Math.Sqrt(T-t));
            // Judge if it's call option
            if (Iscall == true)
            {
                // Using cdf function in "MathNet"package to calculate delta
                delta = Normal.CDF(0, 1, d1);
            }
            else
            {
                delta = Normal.CDF(0, 1, d1) - 1;
            }

            return delta;
        }

    }
}
