namespace Catalog.Entities
{ 
    public class InterestRate
    {
        public int Id { get; set; }
        public double Tenor { get; set; }
        public double Rate { get; set; }
    }
}