using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System.ComponentModel.DataAnnotations.Schema; 
using System.Linq;
using Npgsql;

namespace datastruct{

public class Database
{
    public static void FinancialInstrument(int id, string exchange, double Underlying, )
}


[Table ("InstrumentType")]
public class InstrumentType
{
    public int typeId {get;set;}
    public string typeName{get;set;}

}

[Table ("FinancialInstruments")]
public class FinancialInstruments
{
    public int Id { get; set; }
    public string Ticker { get; set; }
    public string Exchange { get; set; }
    public string Underlying { get; set; }
    public int InstTypeId { get; set; }
    public string CompanyName { get; set; }
    public Nullable<bool> IsCall { get; set; }
    public Nullable<double> Strike { get; set; }
    public Nullable<double> Tenor { get; set; }
    public Nullable<double> Rebate { get; set; }
    public Nullable<double> Barrier { get; set; }
    public KnockType KnockType { get; set; }

    public virtual InstType InstType { get; set; }

    enum KnockType
    {
        DownOut,
        UpOut,
        DownIn,
        UpIn
    } 

}

[Table("Rate")]
public class Rate
{
    public int rateid {get;set;}
    public double term_in_years {get;set;}
    public double rate {get;set;}

}


[Table("Trade")]
public class Trade
{
    public int tradeId {get;set;}
    public double tradeAmount {get;set;}
    public double timeStamp {get;set;}
    public double tradePrice {get;set;}
    public Boolean isbuy {get;set;}

}

[Table("HistoricalPrice")]

public class Historical_price
{
    public int Id { get; set;}
    public List<double>prices {get;set;}
    public int instrumentId {get;set;}
    public DateTime Date {get;set;}

}

}