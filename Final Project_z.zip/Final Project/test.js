let myObject = {
    id:1,
    name: "chris",
    getName: function(){
        return this.name;
    }
};

console.log("Id" + myObject['id'] + "name: "+ myObject['name']);
console.log(myObject.getName());