
const inputs = document.getElementsByClassName('optionInputs');
//const log = document.getElementById('log');
let myButton = document.getElementById('button1');

myButton.addEventListener('click', function (x) { clickEvent(x)});

// if(inputs){
//     myButton.addEventListener('click', function (x) { clickEvent(x)});
// }

function clickEvent(event){

    event.preventDefault();


    var anti = (document.getElementById('antithetic').value === 'True');
    var cv = (document.getElementById('deltaControl').value === 'True');
    var multi = (document.getElementById('multiThreading').value === 'True');
    var is = (inputs.call.value === 'True');


    var field ={
        "type": inputs.optionType.value,
        "Strike":inputs.strike.value,
        "S":inputs.udl.value,
        "T":inputs.T.value,
        "r":inputs.rate.value,
        "sigma":inputs.vol.value,
        "steps":inputs.steps.value,
        "trails":inputs.trails.value,
        "Anti" : anti,
        "CV": cv,
        "Multi": multi,
        "rebate":inputs.rebate.value,
        "isCall":is,
        "bar":inputs.bar.value,
        "UpOut": inputs.upOutRadio.checked,
        "UpIn": inputs.upInRadio.checked,
        "DownOut":inputs.downOutRadio.checked,
        "DownIn":inputs.downInRadio.checked
    }

const list = document.createDocumentFragment();

    fetch('http://localhost:5099/calculate', {
        method: "POST",
        headers:{
            'Content-Type':'application/json'
        },
        body: JSON.stringify(field)
    })
        .then(response => response.json())
        // .then(data => {console.log(data)})
        // .catch(err => console.log(err));

        .then(data => {
            console.log(data)


            let results = Object.values(data);
            document.getElementById('price').innerHTML= "Price: "+ results[0].toFixed(2);
            document.getElementById('SE').innerHTML= "StandardError: "+ results[1].toFixed(2);

            document.getElementById('delta').innerHTML= "Delta: "+ results[2].toFixed(2);

            document.getElementById('gamma').innerHTML= "Gamma: "+ results[3].toFixed(2);

            document.getElementById('vega').innerHTML= "Vega: "+ results[4].toFixed(2);

            document.getElementById('theta').innerHTML= "Theta: "+ results[5].toFixed(2);
            document.getElementById('rho').innerHTML= "Rho: "+ results[6].toFixed(2);


             })

        .catch(err => console.log(err));


}