

using MC_CV;

    public class OptionInputs
    {
        internal Simulator sim;

        public string type { get; set; }
        // public double Tenor { get; set; }
        // public double Rate { get; set; }
        public double Strike { get; set; }
        public double S { get; set; }
        public double T { get; set; }
        public double r { get; set; }
        public double sigma { get; set; }
        // public long Simulator { get; set; }

        public long steps { get; set; } //N
        public int trails { get; set; } //M
        public bool Anti { get; set; }
        public bool CV { get; set; }

        public bool Multi { get; set; }

        public bool Iscall { get; set; } // Call or Put
        
        public double rebate { get; set; }

        public double bar {get; set;}
       
        public bool UpOut { get; set; }
        public bool UpIn { get; set; }
        public bool DownOut { get; set; }
        public bool DownIn { get; set; }
    }


